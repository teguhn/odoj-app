<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?=$title_page ?></title>
        <style type="text/css">
        @page {
            margin-top: 0.6em;
            margin-bottom: 0.6em;
            margin-left: 1.5em;
            margin-right: 1.5em;
        }
        table{
            font-size: x-small;
        }
        </style>
    </head>
    <body>
        <h1 align="center">Pendaftar ISTB 2013</h1>
        <p>Total : <?=$total_rows?> | Sudah bayar : <?=$total_paid?></p>
    <table width="100%" border="1" cellspacing="0">
    <thead>
        <tr>
            <th>Full Name</th>
        <?php foreach($field as $fd=>$fn): ?>
            <th><?=$fd ?></td>
        <?php endforeach; ?>
            <th>Registration Fee</th>
            <th>Payment</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($table_data as $u): ?>
        <tr>
            <td><?php echo $u['title'].' '.$u['first_name'].' '.$u['last_name']?></td>
            <?php foreach($field as $fd=>$fn): ?>
            <?php if($fn=='section'){$s=explode(':',$u[$fn]);$u[$fn]=$s[0];} ?>
                <td><?=$u[$fn] ?></td>
            <?php endforeach; ?>
            <td><?=$u['name'].' ('.$u['curr'].' '.number_format($u['fee'], 0, ',', '.').')'?></td>
            <td><?php $u['file']=($u['file'])? 'Yes':'No'; echo $u['file']?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>
    </body>
</html>
       