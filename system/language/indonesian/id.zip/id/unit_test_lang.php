<?php

$lang['ut_test_name'] = 'Nama Tes';
$lang['ut_test_datatype'] = 'Datatipe Tes';
$lang['ut_res_datatype'] = 'Datatipe Yang Diharapkan';
$lang['ut_result'] = 'Hasil';
$lang['ut_undefined'] = 'Nama Tes Tak Terdefinisi';
$lang['ut_file'] = 'Nama File Name';
$lang['ut_line'] = 'Line Number';
$lang['ut_passed'] = 'Berhasil';
$lang['ut_failed'] = 'Gagal';
$lang['ut_boolean'] = 'Boolean';
$lang['ut_integer'] = 'Integer';
$lang['ut_float'] = 'Float';
$lang['ut_double'] = 'Float';
$lang['ut_string'] = 'String';
$lang['ut_array'] = 'Array';
$lang['ut_object'] = 'Object';
$lang['ut_resource'] = 'Resource';
$lang['ut_null'] = 'Null';
$lang['ut_notes'] = '';
$lang[''] = '';
?>